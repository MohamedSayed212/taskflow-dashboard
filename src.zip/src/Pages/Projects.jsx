import { useState } from "react";
import { motion } from "framer-motion";
import { useSearchParams } from "react-router-dom";
import {
  CalendarDays,
  FolderKanban,
  MoreVertical,
  Plus,
  Users,
  X,
} from "lucide-react";

import {
  projectItemAnimation,
  projectPageAnimation,
  projectProgressAnimation,
} from "../animations/projectAnimations";
import { useAppData } from "../Context/useAppData";

function AnimatedProgressBar({ width }) {
  return (
    <div className="h-2.5 overflow-hidden rounded-full bg-gray-200">
      <motion.div
        initial={projectProgressAnimation.initial}
        animate={projectProgressAnimation.animate(width)}
        className="h-2.5 rounded-full bg-gradient-to-r from-purple-500 to-fuchsia-500"
      />
    </div>
  );
}

export default function Projects() {
  const { addProject, projects } = useAppData();
  const [searchParams, setSearchParams] = useSearchParams();
  const [draftName, setDraftName] = useState("");

  const showQuickAdd = searchParams.get("new") === "1";

  const openQuickAdd = () => {
    const next = new URLSearchParams(searchParams);
    next.set("new", "1");
    setSearchParams(next, { replace: false });
  };

  const closeQuickAdd = () => {
    setDraftName("");
    const next = new URLSearchParams(searchParams);
    next.delete("new");
    setSearchParams(next, { replace: true });
  };

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={projectPageAnimation}
      className="min-h-full bg-white py-4 sm:py-6"
    >
      <motion.div
        variants={projectItemAnimation}
        className="mb-6 flex flex-col gap-4 sm:mb-8 sm:flex-row sm:items-center sm:justify-between"
      >
        <div className="min-w-0">
          <h1 className="text-2xl font-bold text-gray-900 sm:text-3xl">Projects</h1>
          <p className="mt-2 text-sm text-gray-500">
            Manage your projects. Data is saved in this browser.
          </p>
        </div>

        <button
          type="button"
          onClick={openQuickAdd}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gray-100 px-5 py-3 text-sm font-semibold text-gray-700 transition-colors hover:bg-violet-100 hover:text-violet-700 sm:w-fit"
        >
          <Plus size={18} />
          Add Project
        </button>
      </motion.div>

      {showQuickAdd ? (
        <motion.div
          variants={projectItemAnimation}
          className="mb-6 rounded-2xl border border-violet-200 bg-violet-50/80 p-4 sm:p-5"
        >
          <div className="mb-3 flex items-start justify-between gap-2">
            <div>
              <h2 className="font-semibold text-violet-900">New project</h2>
              <p className="mt-1 text-xs text-violet-800/90">
                Saved with your other TaskFlow data (localStorage).
              </p>
            </div>
            <button
              type="button"
              onClick={closeQuickAdd}
              className="rounded-lg p-1.5 text-violet-700 hover:bg-violet-100"
              aria-label="Close"
            >
              <X size={18} />
            </button>
          </div>
          <label className="block text-xs font-medium text-violet-800" htmlFor="project-draft">
            Project name
          </label>
          <input
            id="project-draft"
            value={draftName}
            onChange={(e) => setDraftName(e.target.value)}
            placeholder="e.g. Mobile redesign"
            className="mt-1 w-full rounded-xl border border-violet-200 bg-white px-3 py-2 text-sm outline-none ring-violet-400 focus:ring-2"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                if (!draftName.trim()) return;
                addProject({ title: draftName });
                closeQuickAdd();
              }}
              className="rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-700"
            >
              Create project
            </button>
            <button
              type="button"
              onClick={closeQuickAdd}
              className="rounded-xl bg-white px-4 py-2 text-sm font-semibold text-violet-800 ring-1 ring-violet-200 hover:bg-violet-50"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      ) : null}

      <motion.div
        variants={projectPageAnimation}
        className="grid grid-cols-1 gap-5 xl:grid-cols-2"
      >
        {projects.map((project) => (
          <motion.div
            key={project.id}
            variants={projectItemAnimation}
            className="rounded-3xl border border-gray-100 bg-gray-50 p-4 sm:p-6"
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-purple-100 text-purple-600">
                  <FolderKanban size={22} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900">{project.title}</h3>
                  <p className="mt-1 text-sm text-gray-500">{project.description}</p>
                </div>
              </div>
              <MoreVertical size={20} className="shrink-0 text-gray-400" aria-hidden />
            </div>

            <div className="mb-5 flex flex-wrap items-center gap-3">
              <span className="rounded-full bg-purple-100 px-3 py-1 text-xs font-semibold text-purple-600">
                {project.status}
              </span>
              <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500">
                <CalendarDays size={14} />
                {project.deadline}
              </span>
              <span className="flex items-center gap-1 rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500">
                <Users size={14} />
                {project.members} members
              </span>
              <span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-gray-500">
                {project.tasks} tasks
              </span>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between text-sm">
                <span className="font-medium text-gray-600">Project Progress</span>
                <span className="font-bold text-purple-600">{project.progress}</span>
              </div>
              <AnimatedProgressBar width={project.progress} />
            </div>
          </motion.div>
        ))}
      </motion.div>

      <motion.p
        variants={projectItemAnimation}
        className="mt-8 text-center text-xs text-gray-400"
      >
        © 2026 TaskFlow Projects
      </motion.p>
    </motion.div>
  );
}
