/**
 * Add or edit a task. Saves optional `dueIso` (YYYY-MM-DD) for reliable edit reload.
 * Form state lives in a keyed inner component so each open gets correct defaults without syncing in an effect.
 */
import { useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";

import { useAppData } from "@/Context/useAppData";
import { useTasksModal } from "@/Context/useTasksModal";

const PRIORITIES = ["High", "Medium", "Low"];
const STATUSES = ["Pending", "In Progress", "Completed"];

const DEADLINE_PRESETS = [
  { value: "same", days: 0, label: "Due today" },
  { value: "1", days: 1, label: "Due in 1 day" },
  { value: "3", days: 3, label: "Due in 3 days" },
  { value: "7", days: 7, label: "Due in 1 week" },
  { value: "14", days: 14, label: "Due in 2 weeks" },
  { value: "30", days: 30, label: "Due in 1 month" },
  { value: "custom", days: null, label: "Custom date" },
];

const PRESET_VALUE_BY_LABEL = Object.fromEntries(
  DEADLINE_PRESETS.filter((p) => p.days !== null).map((p) => [p.label, p.value]),
);

function todayISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function addCalendarDays(isoDate, dayCount) {
  const d = new Date(`${isoDate}T12:00:00`);
  d.setDate(d.getDate() + dayCount);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function formatDueDate(isoDate) {
  if (!isoDate) return "";
  const d = new Date(`${isoDate}T12:00:00`);
  if (Number.isNaN(d.getTime())) return isoDate;
  return d.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function getFormInitialState(editingTask, projectOptions) {
  const firstProject = projectOptions[0] ?? "General";
  if (editingTask) {
    const iso =
      typeof editingTask.dueIso === "string" && editingTask.dueIso
        ? editingTask.dueIso
        : todayISO();
    const preset =
      editingTask.deadlineDuration &&
      PRESET_VALUE_BY_LABEL[editingTask.deadlineDuration]
        ? PRESET_VALUE_BY_LABEL[editingTask.deadlineDuration]
        : "custom";
    return {
      title: editingTask.title ?? "",
      dueDate: iso,
      deadlinePreset: preset,
      priority: editingTask.priority ?? "Medium",
      status: editingTask.status ?? "Pending",
      project: editingTask.project || firstProject,
    };
  }
  const today = todayISO();
  return {
    title: "",
    dueDate: today,
    deadlinePreset: "same",
    priority: "Medium",
    status: "Pending",
    project: firstProject,
  };
}

function AddTaskModalContent({
  editingTask,
  projectOptions,
  closeAddTaskModal,
  addTask,
  updateTask,
}) {
  const init = getFormInitialState(editingTask, projectOptions);
  const [title, setTitle] = useState(() => init.title);
  const [dueDate, setDueDate] = useState(() => init.dueDate);
  const [deadlinePreset, setDeadlinePreset] = useState(() => init.deadlinePreset);
  const [priority, setPriority] = useState(() => init.priority);
  const [status, setStatus] = useState(() => init.status);
  const [project, setProject] = useState(() => init.project);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    const today = todayISO();
    const preset = DEADLINE_PRESETS.find((p) => p.value === deadlinePreset);

    let iso = dueDate?.trim() || today;
    if (deadlinePreset !== "custom" && preset && preset.days !== null) {
      iso = addCalendarDays(today, preset.days);
    }

    const deadlineDuration =
      deadlinePreset === "custom" ? undefined : preset?.label ?? undefined;

    const basePayload = {
      title: title.trim(),
      project: project || projectOptions[0] || "General",
      status,
      priority,
      date: formatDueDate(iso),
      dueIso: iso,
    };

    if (editingTask) {
      updateTask(editingTask.id, {
        ...basePayload,
        deadlineDuration: deadlineDuration ?? null,
      });
    } else {
      addTask({
        ...basePayload,
        ...(deadlineDuration ? { deadlineDuration } : {}),
      });
    }
    closeAddTaskModal();
  };

  const heading = editingTask ? "Edit task" : "Add new task";
  const submitLabel = editingTask ? "Save changes" : "Add task";

  return (
    <div
      className="w-full max-w-md overflow-x-hidden rounded-3xl border border-white/80 bg-white shadow-2xl"
      onClick={(ev) => ev.stopPropagation()}
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-task-title"
    >
      <div className="flex items-center justify-between border-b border-slate-100 bg-gradient-to-r from-violet-50 to-cyan-50 px-5 py-4">
        <h2 id="add-task-title" className="text-lg font-bold text-slate-900">
          {heading}
        </h2>
        <button
          type="button"
          onClick={closeAddTaskModal}
          className="rounded-lg p-2 text-slate-500 hover:bg-white/80 hover:text-slate-800"
          aria-label="Close"
        >
          <X size={20} />
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 p-5">
        <div>
          <label
            htmlFor="add-task-name"
            className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
          >
            Task name
          </label>
          <input
            id="add-task-name"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            placeholder="What needs to be done?"
            className="mt-1 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
          />
        </div>

        <div>
          <label
            htmlFor="add-task-deadline-preset"
            className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
          >
            Deadline duration
          </label>
          <p className="mt-0.5 text-xs text-slate-400">
            Pick how long until it is due, or choose “Custom date”.
          </p>
          <select
            id="add-task-deadline-preset"
            value={deadlinePreset}
            onChange={(e) => {
              const value = e.target.value;
              setDeadlinePreset(value);
              if (value === "custom") return;
              const p = DEADLINE_PRESETS.find((x) => x.value === value);
              if (p && p.days !== null) {
                setDueDate(addCalendarDays(todayISO(), p.days));
              }
            }}
            className="mt-2 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
          >
            {DEADLINE_PRESETS.map((p) => (
              <option key={p.value} value={p.value}>
                {p.label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label
            htmlFor="add-task-due"
            className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
          >
            Due date
          </label>
          <p className="mt-0.5 text-xs text-slate-400">
            Leave empty to use <strong className="text-slate-600">today</strong> when you save.
          </p>
          <input
            id="add-task-due"
            type="date"
            value={dueDate}
            onChange={(e) => {
              setDueDate(e.target.value);
              setDeadlinePreset("custom");
            }}
            className="mt-2 w-full rounded-xl border border-slate-200 px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label
              htmlFor="add-task-priority"
              className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
            >
              Priority
            </label>
            <select
              id="add-task-priority"
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label
              htmlFor="add-task-status"
              className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
            >
              Status
            </label>
            <select
              id="add-task-status"
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
            >
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label
            htmlFor="add-task-project"
            className="block text-xs font-semibold uppercase tracking-wide text-slate-500"
          >
            Project
          </label>
          <select
            id="add-task-project"
            value={project}
            onChange={(e) => setProject(e.target.value)}
            className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none ring-violet-400 focus:border-violet-300 focus:ring-2"
          >
            {projectOptions.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap justify-end gap-2 pt-2">
          <button
            type="button"
            onClick={closeAddTaskModal}
            className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-violet-700"
          >
            {submitLabel}
          </button>
        </div>
      </form>
    </div>
  );
}

const AddTaskModal = () => {
  const {
    addTaskModalOpen,
    closeAddTaskModal,
    editingTask,
    modalSession,
  } = useTasksModal();
  const { addTask, projects, tasks, updateTask } = useAppData();

  const projectOptions = useMemo(() => {
    const names = new Set(projects.map((p) => p.title));
    tasks.forEach((t) => names.add(t.project));
    const list = Array.from(names).sort();
    return list.length ? list : ["General"];
  }, [projects, tasks]);

  useEffect(() => {
    if (!addTaskModalOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [addTaskModalOpen]);

  useEffect(() => {
    if (!addTaskModalOpen) return;
    const onKey = (e) => {
      if (e.key === "Escape") closeAddTaskModal();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [addTaskModalOpen, closeAddTaskModal]);

  if (!addTaskModalOpen) return null;

  const modal = (
    <div
      className="fixed inset-0 z-[220] flex min-h-0 items-start justify-center overflow-y-auto bg-slate-950/50 p-4 py-8 backdrop-blur-sm sm:items-center sm:py-10"
      onClick={closeAddTaskModal}
      role="presentation"
    >
      <AddTaskModalContent
        key={modalSession}
        editingTask={editingTask}
        projectOptions={projectOptions}
        closeAddTaskModal={closeAddTaskModal}
        addTask={addTask}
        updateTask={updateTask}
      />
    </div>
  );

  return createPortal(modal, document.body);
};

export default AddTaskModal;
