/**
 * SideBar — left navigation.
 *
 * - Desktop (`lg` and up): always visible in the layout.
 * - Phone/tablet: hidden off-screen until `mobileOpen` is true (controlled by App.jsx).
 */
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import logo from "../assets/logo.png";
import profilePicture from "../assets/profilePicture.webp";
import { Link, NavLink } from "react-router-dom";
import {
  ArrowUpRight,
  ArrowUpToLine,
  Bookmark,
  CalendarCheck,
  ChevronDown,
  ClipboardList,
  Folder,
  FolderKanban,
  LayoutGrid,
  Plus,
  Search,
  X,
} from "lucide-react";
import {
  InputGroup,
  InputGroupAddon,
} from "@/Components/ui/input-group";
import { useAppData } from "@/Context/useAppData";
import { useSearch } from "@/Context/useSearch";
import { useTasksModal } from "@/Context/useTasksModal";
import { cn } from "@/lib/utils";

const sidebarIconMap = {
  ArrowUpToLine,
  Bookmark,
  CalendarCheck,
  ClipboardList,
  Folder,
  FolderKanban,
  LayoutGrid,
};

const getSidebarIcon = (iconName) => sidebarIconMap[iconName] ?? Folder;

const SideBar = ({ mobileOpen = false, onMobileClose = () => {} }) => {
  const { openAddTaskModal } = useTasksModal();
  const {
    currentUser,
    menuItems,
    searchItems,
    sidebarDeadlines,
    sidebarProjects,
  } = useAppData();
  const { searchValue, setSearchValue } = useSearch();
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef(null);

  // Keep the page from scrolling behind the centered search popup.
  useEffect(() => {
    if (!isSearchOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [isSearchOpen]);

  const normalizedSearch = searchValue.trim().toLowerCase();
  const searchResults = normalizedSearch
    ? searchItems.filter((item) =>
        `${item.title} ${item.description} ${item.type}`
          .toLowerCase()
          .includes(normalizedSearch),
      )
    : searchItems.slice(0, 7);

  useEffect(() => {
    if (!isSearchOpen) return;

    searchInputRef.current?.focus();

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setIsSearchOpen(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isSearchOpen]);

  // Search UI is rendered with createPortal(..., document.body) below.
  // Reason: this <aside> uses CSS transform for the mobile slide animation.
  // Any `position: fixed` child would be pinned to that transformed box, not
  // the full browser window — so the popup looked “stuck” to the sidebar.

  const searchModal =
    isSearchOpen &&
    createPortal(
      <div
        className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm"
        onClick={() => setIsSearchOpen(false)}
        role="presentation"
      >
        <div
          className="flex max-h-[min(85dvh,640px)] w-full max-w-2xl flex-col overflow-hidden rounded-3xl border border-white/80 bg-white/95 shadow-2xl shadow-violet-950/20"
          onClick={(event) => event.stopPropagation()}
          role="dialog"
          aria-modal="true"
          aria-label="Search"
        >
          <div className="border-b border-slate-100 bg-gradient-to-r from-violet-50 via-sky-50 to-cyan-50 p-4">
            <div className="flex items-center gap-3 rounded-2xl border border-white bg-white/90 px-4 py-3 shadow-sm">
              <Search size={20} className="shrink-0 text-violet-500" />
              <input
                ref={searchInputRef}
                type="text"
                aria-label="Global search"
                placeholder="Search pages, tasks, projects, reports..."
                value={searchValue}
                onChange={(event) => setSearchValue(event.target.value)}
                className="min-w-0 flex-1 bg-transparent text-sm font-medium text-slate-800 outline-none placeholder:text-slate-400"
              />

              <button
                type="button"
                onClick={() => setIsSearchOpen(false)}
                className="rounded-lg p-1.5 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
                aria-label="Close search"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto p-3">
            <div className="mb-2 flex items-center justify-between px-2 text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
              <span>{normalizedSearch ? "Results" : "Quick access"}</span>
              <span>{searchResults.length}</span>
            </div>

            {searchResults.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-200 bg-slate-50 p-8 text-center">
                <p className="font-semibold text-slate-700">No matching results</p>
                <p className="mt-1 text-sm text-slate-400">
                  Try searching for tasks, projects, reports, or requests.
                </p>
              </div>
            ) : (
              <div className="space-y-1">
                {searchResults.map((item) => {
                  const Icon = getSidebarIcon(item.iconName);

                  return (
                    <Link
                      key={`${item.type}-${item.title}`}
                      to={item.url}
                      onClick={() => {
                        setIsSearchOpen(false);
                        onMobileClose();
                      }}
                      className="group flex items-center gap-3 rounded-2xl px-3 py-3 transition hover:bg-violet-50"
                    >
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-50 to-cyan-50 text-violet-500 ring-1 ring-violet-100/70">
                        <Icon size={20} />
                      </span>

                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-bold text-slate-800">
                          {item.title}
                        </span>
                        <span className="mt-0.5 block truncate text-xs font-medium text-slate-400">
                          {item.type} - {item.description}
                        </span>
                      </span>

                      <ArrowUpRight
                        size={17}
                        className="text-slate-300 transition group-hover:text-violet-500"
                      />
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>,
      document.body,
    );

  return (
    <>
    <aside
      className={cn(
        "flex min-h-screen w-[min(100vw,340px)] max-w-[100vw] flex-col overflow-y-auto bg-neutral-100 px-5 py-8 sm:px-7 sm:py-10 lg:static lg:z-auto lg:max-h-none lg:min-h-screen lg:w-[300px] lg:max-w-[300px] lg:translate-x-0 xl:w-[340px] xl:max-w-[340px]",
        "fixed left-0 top-0 z-50 border-r border-neutral-200/80 shadow-xl transition-transform duration-300 ease-out lg:shrink-0 lg:border-r-0 lg:shadow-none",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
      )}
    >
      {/* Logo */}
      <div className="mb-10 flex items-center gap-3 lg:mb-14">
        <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-white shadow-md shadow-violet-200/50 ring-1 ring-violet-100">
          <div className="absolute inset-1 rounded-[18px] bg-gradient-to-br from-violet-500/10 via-fuchsia-500/10 to-sky-400/15" />

          <div
            aria-label="TaskFlow logo"
            role="img"
            className="relative h-10 w-10 bg-gradient-to-br from-violet-600 via-fuchsia-500 to-sky-500"
            style={{
              WebkitMask: `url(${logo}) center / contain no-repeat`,
              mask: `url(${logo}) center / contain no-repeat`,
            }}
          />
        </div>
        {/* text */}
        <h2 className="bg-gradient-to-r from-violet-600 via-fuchsia-500 to-sky-500 bg-clip-text text-2xl font-bold tracking-tight text-transparent">
          TaskFlow
        </h2>
      </div>

      {/* Profile Card */}
      <div className="flex items-center gap-3 rounded-xl border border-neutral-300 bg-neutral-50 p-2.5">
        <img
          src={profilePicture}
          alt="Profile"
          className="h-12 w-12 rounded-full"
        />

        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-neutral-700">
            {currentUser.name?.trim() || "Your name"}
          </p>
          <p className="truncate text-xs text-neutral-500">
            {currentUser.email?.trim() || "you@example.com"}
          </p>
        </div>

        <button className="ml-auto rounded-lg p-2 text-neutral-700 transition-colors duration-200 hover:bg-neutral-200">
          <ChevronDown size={18} />
        </button>
      </div>

      {/* Search Field */}
      <InputGroup
        className="mt-3 h-11 cursor-pointer rounded-xl border-neutral-300 bg-neutral-50 transition hover:border-violet-200 hover:bg-white"
        onClick={() => setIsSearchOpen(true)}
      >
        <button
          type="button"
          className="min-w-0 flex-1 truncate text-left text-sm text-neutral-500"
        >
          {searchValue || "Search anything..."}
        </button>
        <InputGroupAddon>
          <Search />
        </InputGroupAddon>
      </InputGroup>

      {/* Opens the add-task popup (see AddTaskModal.jsx). */}
      <button
        type="button"
        onClick={() => {
          openAddTaskModal();
          onMobileClose();
        }}
        className="mt-7 flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-neutral-200 text-sm font-semibold text-neutral-700 shadow-none transition-colors duration-200 hover:bg-violet-100 hover:text-violet-700"
      >
        Add New Task
        <Plus size={18} />
      </button>

      {/* Main Menu */}
      <div className="mt-10 ml-0.5 lg:mt-12">
        {/* Heading */}
        <h3 className="mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-neutral-400">
          Main Menu
        </h3>

        {/* Items In Menu */}
        <div className="space-y-1">
          {menuItems.map((item) => {
            const Icon = getSidebarIcon(item.iconName);

            return (
              <NavLink
                key={item.id}
                to={item.url}
                end={item.url === "/"}
                onClick={onMobileClose}
                className={({ isActive }) =>
                  cn(
                    "group flex w-full items-center gap-[10px] rounded-xl px-4 py-3 text-[15px] font-medium transition-all duration-200",
                    isActive
                      ? "bg-violet-100 text-violet-800"
                      : "text-neutral-500 hover:bg-violet-100/70 hover:text-violet-700",
                  )
                }
              >
                <Icon size={22} className="shrink-0 transition-colors duration-200" />
                <span>{item.title}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Bottom Line */}
        <div className="mt-5 border-b border-neutral-200"></div>
      </div>
      {/* incoming deadline */}
      <div className="mt-6 ml-1">
        {/* Heading */}
        <h3 className="mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-neutral-400">
          Incoming Deadline
        </h3>

        {/* Items */}
        <div className="space-y-2">
          {sidebarDeadlines.map((item) => {
            const Icon = getSidebarIcon(item.iconName);

            return (
              <NavLink
                to={item.url}
                key={item.id}
                onClick={onMobileClose}
                className={({ isActive }) =>
                  cn(
                    "group flex w-full items-center gap-2 rounded-xl px-4 py-3 text-[15px] font-medium transition-all duration-200",
                    isActive
                      ? "bg-violet-100 text-violet-800"
                      : "text-neutral-500 hover:bg-violet-100/70 hover:text-violet-700",
                  )
                }
              >
                <Icon
                  size={22}
                  strokeWidth={1.8}
                  className="shrink-0 text-neutral-400 transition-colors duration-200 group-hover:text-violet-700"
                />
                <span>{item.title}</span>
              </NavLink>
            );
          })}
        </div>

        {/* Bottom line */}
        <div className="mt-8 border-b border-neutral-200"></div>
      </div>

      {/* My Projects */}
      <div className="mt-6 ml-1">
        {/* Heading */}
        <h3 className="mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-neutral-400">
          My Project&apos;s
        </h3>

        {/* Items */}
        <div className="space-y-1">
          {sidebarProjects.map((item) => {
            const Icon = getSidebarIcon(item.iconName);

            return (
              <NavLink
                key={item.id}
                to={item.url}
                onClick={onMobileClose}
                className={({ isActive }) =>
                  cn(
                    "group flex w-full items-center gap-4 rounded-xl px-4 py-3 text-[15px] font-medium transition-all duration-200",
                    isActive
                      ? "bg-violet-100 text-violet-800"
                      : "text-neutral-500 hover:bg-violet-100/70 hover:text-violet-700",
                  )
                }
              >
                <Icon
                  size={22}
                  strokeWidth={1.8}
                  className="shrink-0 text-neutral-400 transition-colors duration-200 group-hover:text-violet-700"
                />
                <span>{item.title}</span>
              </NavLink>
            );
          })}
        </div>
      </div>
    </aside>
    {searchModal}
    </>
  );
};

export default SideBar;
