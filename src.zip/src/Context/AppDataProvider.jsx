/**
 * AppDataProvider — single app state loaded from localStorage and saved on change.
 * Initial template comes from `lib/defaultAppData.js` (not from src/data).
 */
import { useCallback, useEffect, useMemo, useState } from "react";

import { buildSearchItems } from "@/lib/buildSearchItems";
import {
  loadPersistedAppData,
  persistAppData,
} from "@/lib/appStorage";
import { AppDataContext } from "./AppDataContext";

export const AppDataProvider = ({ children }) => {
  const [appData, setAppData] = useState(() => loadPersistedAppData());

  useEffect(() => {
    persistAppData(appData);
  }, [appData]);

  const addTask = useCallback((taskPayload) => {
    setAppData((d) => {
      const nextId = d.tasks.reduce((m, t) => Math.max(m, t.id), 0) + 1;
      const row = { ...taskPayload, id: nextId };
      if (row.deadlineDuration == null) delete row.deadlineDuration;
      return { ...d, tasks: [...d.tasks, row] };
    });
  }, []);

  const updateTask = useCallback((id, patch) => {
    setAppData((d) => ({
      ...d,
      tasks: d.tasks.map((t) => {
        if (t.id !== id) return t;
        const merged = { ...t, ...patch };
        if (Object.prototype.hasOwnProperty.call(patch, "deadlineDuration")) {
          if (patch.deadlineDuration == null) delete merged.deadlineDuration;
        }
        return merged;
      }),
    }));
  }, []);

  const deleteTask = useCallback((id) => {
    setAppData((d) => ({
      ...d,
      tasks: d.tasks.filter((t) => t.id !== id),
    }));
  }, []);

  const addProject = useCallback(({ title, description }) => {
    const trimmed = title?.trim();
    if (!trimmed) return;

    setAppData((d) => {
      const nextId = d.projects.reduce((m, p) => Math.max(m, p.id), 0) + 1;
      return {
        ...d,
        projects: [
          ...d.projects,
          {
            id: nextId,
            title: trimmed,
            description: description?.trim() || "New project in TaskFlow.",
            tasks: 0,
            members: 1,
            progress: "0%",
            status: "Pending",
            deadline: "TBD",
          },
        ],
      };
    });
  }, []);

  const updateRequest = useCallback((id, patch) => {
    setAppData((d) => ({
      ...d,
      requests: d.requests.map((r) => (r.id === id ? { ...r, ...patch } : r)),
    }));
  }, []);

  const addRequest = useCallback(({ name, title, task }) => {
    const n = name?.trim();
    const t = title?.trim();
    const body = task?.trim();
    if (!n || !t) return;

    setAppData((d) => {
      const nextId = d.requests.reduce((m, r) => Math.max(m, r.id), 0) + 1;
      const time = new Date().toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
      return {
        ...d,
        requests: [
          ...d.requests,
          {
            id: nextId,
            name: n,
            title: t,
            task: body || "—",
            time,
            status: "Pending",
          },
        ],
      };
    });
  }, []);

  const deleteRequest = useCallback((id) => {
    setAppData((d) => ({
      ...d,
      requests: d.requests.filter((r) => r.id !== id),
    }));
  }, []);

  const addReport = useCallback(({ title, type }) => {
    const trimmed = title?.trim();
    if (!trimmed) return;

    setAppData((d) => {
      const nextId = d.reports.reduce((m, r) => Math.max(m, r.id ?? 0), 0) + 1;
      const date = new Date().toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        year: "numeric",
      });
      return {
        ...d,
        reports: [
          ...d.reports,
          {
            id: nextId,
            title: trimmed,
            type: type?.trim() || "Summary",
            date,
          },
        ],
      };
    });
  }, []);

  const deleteReport = useCallback((id) => {
    setAppData((d) => ({
      ...d,
      reports: d.reports.filter((r) => r.id !== id),
    }));
  }, []);

  const searchItems = useMemo(
    () =>
      buildSearchItems({
        tasks: appData.tasks,
        projects: appData.projects,
        requests: appData.requests,
        reports: appData.reports,
        menuItems: appData.menuItems,
        sidebarDeadlines: appData.sidebarDeadlines,
        sidebarProjects: appData.sidebarProjects,
      }),
    [appData],
  );

  const value = {
    ...appData,
    addProject,
    addReport,
    addRequest,
    addTask,
    deleteReport,
    deleteRequest,
    deleteTask,
    searchItems,
    updateRequest,
    updateTask,
  };

  return (
    <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>
  );
};
