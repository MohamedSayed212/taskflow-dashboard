import { useCallback, useMemo, useState } from "react";

import { TasksModalContext } from "./TasksModalContext";

export function TasksModalProvider({ children }) {
  const [addTaskModalOpen, setAddTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  /** Bumps when the modal opens so the form remounts with fresh initial state (no effect sync). */
  const [modalSession, setModalSession] = useState(0);

  const openAddTaskModal = useCallback(() => {
    setEditingTask(null);
    setModalSession((n) => n + 1);
    setAddTaskModalOpen(true);
  }, []);

  const openEditTaskModal = useCallback((task) => {
    setEditingTask(task);
    setModalSession((n) => n + 1);
    setAddTaskModalOpen(true);
  }, []);

  const closeAddTaskModal = useCallback(() => {
    setAddTaskModalOpen(false);
    setEditingTask(null);
  }, []);

  const value = useMemo(
    () => ({
      addTaskModalOpen,
      closeAddTaskModal,
      editingTask,
      modalSession,
      openAddTaskModal,
      openEditTaskModal,
    }),
    [
      addTaskModalOpen,
      closeAddTaskModal,
      editingTask,
      modalSession,
      openAddTaskModal,
      openEditTaskModal,
    ],
  );

  return (
    <TasksModalContext.Provider value={value}>
      {children}
    </TasksModalContext.Provider>
  );
}
